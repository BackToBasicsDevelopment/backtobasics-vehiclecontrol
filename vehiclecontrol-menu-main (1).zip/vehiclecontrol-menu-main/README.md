 **Vehicle Control Menu**
**BackToBasics**

Here is our first release on these forums. We spent a little bit of time developing this simple, standalone menu for your vehicle controls.

Our system is really intuitive and currently contains the following features:
 - Vehicle Saving
 - Driver/Passenger Window Rolling
 - Alarm System [WIP]
 - Lock System [WIP]
 - Door Controls
 - Engine toggle

We intend on adding a few more features to this menu before we are happy to call it complete.

**Usage & Controls**

U - If pressed when inside a vehicle, vehicle will be saved to the player. If pressed again will toggle the menu.
P - If pressed when inside a vehicle, will toggle vehicle's engine state (On/Off)

**Installation**

Place the vehiclecontrol folder into your resources directory.
Add start vehiclecontrol to your server.cfg

We hope you enjoy our first release. We hope to bring much more content to the community in time.


**BackToBasics Discord:** https://discord.gg/PB3yG59
